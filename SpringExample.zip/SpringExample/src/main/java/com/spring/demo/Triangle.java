package com.spring.demo;

public class Triangle implements Shape {

	String color;
	
	
	
	public Triangle(String color) {
		super();
		this.color = color;
	}



	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("painter is drawing "+color+" triangle");
	}
	
	

}
