package com.spring.demo;

public class Dancer implements Performer {

	@Override
	public void perform() {
		
		System.out.println("dancer is dancing on main hun na song");
		
	}

}
