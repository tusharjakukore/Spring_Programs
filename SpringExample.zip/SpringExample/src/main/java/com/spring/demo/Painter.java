package com.spring.demo;
//there are two ways to inject the object
//1)constructor
//2)setter
public class Painter implements Performer{
	
	Shape shape;
	
	public Painter(Shape shape) {
		super();
		this.shape = shape;
	}

	@Override
	public void perform() {
		
		shape.draw();
	}

	

}
