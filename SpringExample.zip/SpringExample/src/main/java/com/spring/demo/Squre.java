package com.spring.demo;

public class Squre implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("drawing a squre");
	}
	
	

}
