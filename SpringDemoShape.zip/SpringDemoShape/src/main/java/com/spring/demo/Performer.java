package com.spring.demo;

public interface Performer {

	void perform();
}
