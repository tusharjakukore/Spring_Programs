package com.spring.demo;

public interface Shape {
	
	void draw();

}
