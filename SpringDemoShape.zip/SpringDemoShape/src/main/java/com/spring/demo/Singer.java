package com.spring.demo;

public class Singer implements Performer {

	@Override
	public void perform() {
		// TODO Auto-generated method stub
		System.out.println("I am singing song");
	}

}
