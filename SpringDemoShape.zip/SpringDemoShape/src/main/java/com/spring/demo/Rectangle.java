package com.spring.demo;

public class Rectangle implements Shape{

	private String color;
	
	public Rectangle(String color) {
		super();
		this.color = color;
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("painter is drawing" + color +"rectangle");
	}
	

}
