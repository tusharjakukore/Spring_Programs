package com.spring.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("kalpesh")
public class Manager implements Employee{
	
	@Autowired
	@Qualifier("axis")
	Client cli;
	

	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	



	public Manager(Client cli) {
		super();
		this.cli = cli;
	}





	@Override
	public void work() {
		
		cli.project();
		
	}

}
