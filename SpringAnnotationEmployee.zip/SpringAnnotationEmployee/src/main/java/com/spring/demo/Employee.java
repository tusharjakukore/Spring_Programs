package com.spring.demo;


public interface Employee {
	
	
	
	
	void work();

}
