package com.spring.demo;

public interface Client {
	
	void project();

}
