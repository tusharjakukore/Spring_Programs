package com.spring.demo;

import org.springframework.stereotype.Component;

@Component("dev")
public class Developer implements Employee {
	
	

	public Developer() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void work() {
		
		System.out.println("Developer is creating the application");
		
	}

}
