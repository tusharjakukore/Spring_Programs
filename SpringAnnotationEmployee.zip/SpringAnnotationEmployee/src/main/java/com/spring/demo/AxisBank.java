package com.spring.demo;

import org.springframework.stereotype.Component;

@Component("axis")
public class AxisBank implements Client {
	
	String empType;

	@Override
	public void project() {
		
		System.out.println(" The employee is working for Axis bank project");
		
	}

	
	
}
