package com.spring.demo;

public class Resturant {
	
	HotDrink hotDrink;
	
	String welcomeNote;
	
	public Resturant(HotDrink hotDrink)
	{
		super();
		this.hotDrink=hotDrink;
	}


	public void setWelcomeNote(String welcomeNote) {
		this.welcomeNote = welcomeNote;
	}



	void prepareDrink()
	{
		hotDrink.prepareHotDrink();	
	}

	void greetCustomer()
	{
		System.out.println(welcomeNote);
	}
}
