package com.spring.demo;

public class Coffee implements HotDrink {

	@Override
	public void prepareHotDrink() {
		System.out.println(".....I am preparing coffee");
		
	}

}
