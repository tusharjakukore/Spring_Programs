package com.spring.demo;

public interface HotDrink {
	
	public void prepareHotDrink();

}
