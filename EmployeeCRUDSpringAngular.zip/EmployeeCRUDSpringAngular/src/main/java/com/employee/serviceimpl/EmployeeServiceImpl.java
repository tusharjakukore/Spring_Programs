package com.employee.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.Service.EmployeeService;
import com.employee.entity.Employee;
import com.employee.exception.EmployeeIdNotFoundException;
import com.employee.repository.EmployeeRepository;


@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository empRepo;
	
	
	@Override
	public Employee addEmployee(Employee employee) {
		
		return empRepo.save(employee);
	}

	@Override
	public Employee getEmployeeDetails(int id) {
		
		return empRepo.findById(id).orElseThrow(()->new EmployeeIdNotFoundException("employee id is not correct"));
	}

	@Override
	public Employee updateEmployeeDetails(Employee employee, Integer id) {
		
		Employee UpdateEmployee=empRepo.findById(id).orElseThrow(()->new EmployeeIdNotFoundException("employee id is not correct"));
		UpdateEmployee.setFirstName(employee.getFirstName());
		UpdateEmployee.setLastName(employee.getLastName());
		UpdateEmployee.setEmpEmail(employee.getEmpEmail());
		
		return empRepo.save(UpdateEmployee);
	}

	@Override
	public void deleteEmployeeDetails(int id) {
		
		Employee deleteEmployee=empRepo.findById(id).orElseThrow(()->new EmployeeIdNotFoundException("employee id is not correct"));
		empRepo.delete(deleteEmployee);
	}
	

}
