package com.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.Service.EmployeeService;
import com.employee.entity.Employee;

import jakarta.validation.Valid;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService empvice;
	
	@PostMapping("/Employee/addEmployee")
	public ResponseEntity<Employee> saveEmployee(@Valid @RequestBody Employee employee)
	{
		return new ResponseEntity<Employee>(empvice.addEmployee(employee),HttpStatus.CREATED);
	}
	
	@GetMapping("/Employee/getEmployee/{id}")
	public ResponseEntity<Employee> getEmployee(@PathVariable("id") int id)
	{
		return new ResponseEntity<Employee>(empvice.getEmployeeDetails(id),HttpStatus.OK);
	}
	
	@DeleteMapping("/Employee/removeEmployee/{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable("id") int id)
	{
		return new ResponseEntity<String>("Delete successfully...",HttpStatus.OK);
	}
	
	//use put mapping to edit existing data
	@PutMapping("/Employee/updateEmployee/{id}")
	public ResponseEntity<Employee> editEmployee(@PathVariable("id") Integer id, @Valid @RequestBody Employee employee)
	{
		Employee updateEmployee=empvice.updateEmployeeDetails(employee , id);
		return new ResponseEntity<Employee>(updateEmployee , HttpStatus.OK); 
	}


}
