package com.employee.Service;

import com.employee.entity.Employee;

public interface EmployeeService {
	
    Employee addEmployee(Employee employee);
	
	Employee getEmployeeDetails(int id);
	
	Employee updateEmployeeDetails(Employee employee,Integer id);
	
	void deleteEmployeeDetails(int id);

}
