package com.hiking.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hiking.entity.Payment;
import com.hiking.exception.PaymentIdNotFoundException;
import com.hiking.repository.PaymentRepository;
import com.hiking.service.PaymentService;

@Service
public class PaymentServiceImplements implements PaymentService {
	
	@Autowired
	PaymentRepository pyRepo;

	@Override
	public Payment addPayment(Payment payment) {
		
		return pyRepo.save(payment);
		
	}

	@Override
	public Payment getPaymentDetails(int paymentId) {
		
		return pyRepo.findById(paymentId).orElseThrow(()->new PaymentIdNotFoundException("payment id is not correct"));
		
	}

	@Override
	public Payment updatePaymentDetails(Payment payment, Integer paymentId) {
		
		Payment UpdatePayment=pyRepo.findById(paymentId).orElseThrow(()->new PaymentIdNotFoundException("payment id is not correct"));
		UpdatePayment.setBookingId(payment.getBookingId());
		UpdatePayment.setPaymentDate(payment.getPaymentDate());
		UpdatePayment.setPaymentStatus(payment.getPaymentStatus());
		UpdatePayment.setPaymentMethod(payment.getPaymentMethod());
		return pyRepo.save(UpdatePayment);
		
	}

	@Override
	public void deletePaymentDetails(int paymentId) {
		
		Payment deletePayment=pyRepo.findById(paymentId).orElseThrow(()->new PaymentIdNotFoundException("payment id is not correct"));
		pyRepo.delete(deletePayment);
		
	}
	

}
