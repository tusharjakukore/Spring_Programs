package com.hiking.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hiking.entity.Review;
import com.hiking.exception.ReviewIdNotFoundException;
import com.hiking.repository.ReviewRepository;
import com.hiking.service.ReviewService;


@Service
public class ReviewServiceImplements implements ReviewService{
	
	@Autowired
	ReviewRepository reRepo;

	@Override
	public Review addReview(Review review) {
		
		return reRepo.save(review);
	}

	@Override
	public Review getReviewDetails(int reviewId) {
		
		return reRepo.findById(reviewId).orElseThrow(()->new ReviewIdNotFoundException("review id is not correct"));
	}

	@Override
	public Review updateReviewDetails(Review review, Integer reviewId) {
		
		Review UpdateReview=reRepo.findById(reviewId).orElseThrow(()->new ReviewIdNotFoundException("review id is not correct"));
		UpdateReview.setUserId(review.getUserId());
		UpdateReview.setEventId(review.getEventId());
		UpdateReview.setRating(review.getRating());
		UpdateReview.setComment(review.getComment());
		return reRepo.save(UpdateReview);
	}

	@Override
	public void deleteReviewDetails(int reviewId) {
		
		Review deleteReview=reRepo.findById(reviewId).orElseThrow(()->new ReviewIdNotFoundException("review id is not correct"));
		reRepo.delete(deleteReview);
	}

}
