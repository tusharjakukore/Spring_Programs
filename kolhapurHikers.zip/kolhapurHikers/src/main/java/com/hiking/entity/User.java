package com.hiking.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="user1")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;
	
	@Column(length=50, nullable = false)
	private String firstname;
	
	@Column(length=50, nullable = false)
	private String lastname;
	
	@Column(length=50, nullable = false)
	private String email;
	
	@Column(length=50, nullable = false)
	private String city;

	
	@Column(length=50, nullable = false)
	private String phone ;
	
	@Column(length=50, nullable = false)
	private String password;
	
//	 
//	@OneToMany(mappedBy = "user",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JsonManagedReference
//	List<Booking> booking;
//	
//	@OneToMany(mappedBy = "user",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JsonManagedReference
//	List<Review> review;
//	
//	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinColumn(name = "admin", referencedColumnName = "adminId")
//	@JsonBackReference
//	private Admin admin;
	
	
}
