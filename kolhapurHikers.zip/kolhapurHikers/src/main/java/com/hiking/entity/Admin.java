package com.hiking.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table (name="admin_details")
public class Admin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int adminId;
	
	@Column(length=50, nullable = false)
	private String firstName;
	
	@Column(length=50, nullable = false)
	private String lastName;
	
	@Column(length=50, nullable = false)
	private String email;

	@Pattern(regexp = "[6789]{1}[0-9]{9}", message="Phone number should consist of 10 digits")
	@Size(min=10, max=10, message = "Min and Max 10 digits allowed")
	@Column(length=50, nullable = false)
	private String phone ;
	
	@Column(length=50, nullable = false)
	private String password;
	
//	@OneToMany(mappedBy = "admin",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JsonManagedReference
//	List<User> user;
//	
//	@OneToMany(mappedBy = "admin",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JsonManagedReference
//	List<Hiking_Event> hiking_event;
//	
//	@OneToMany(mappedBy = "admin",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JsonManagedReference
//	List<Booking> booking;
//	
//	@OneToMany(mappedBy = "admin",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JsonManagedReference
//	List<Review> review;
//	
//	@OneToMany(mappedBy = "admin",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JsonManagedReference
//	List<Payment> payment;
	

}
