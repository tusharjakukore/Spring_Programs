package com.hiking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hiking.entity.Hiking_Event;



public interface Hiking_EventRepository extends JpaRepository<Hiking_Event, Integer>{

}
