package com.hiking.exception;

public class BookingIdNotFoundException extends RuntimeException{
	

	public BookingIdNotFoundException(String message)
	{
		super(message);
	}

}
