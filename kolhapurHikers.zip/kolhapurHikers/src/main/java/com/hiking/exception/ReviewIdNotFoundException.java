package com.hiking.exception;

public class ReviewIdNotFoundException extends RuntimeException{
	

	public ReviewIdNotFoundException(String message)
	{
		super(message);
	}

}
