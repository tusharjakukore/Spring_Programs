package com.hiking.service;

import java.util.List;

import com.hiking.entity.Admin;


public interface AdminService {
	
    Admin addAdmin(Admin admin);
	
	Admin getAdminDetails(int adminId);
	
	Admin updateAdminDetails(Admin admin,Integer adminId);
	
	void deleteAdminDetails(int adminId);
	
	List<Admin> findAll();

}
