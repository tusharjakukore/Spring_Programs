package com.hiking.service;
import java.util.*;
import com.hiking.entity.User;

public interface UserService {
	
     User addUser(User user);
	
	User getUserDetails(int userId);
	
	User updateUserDetails(User user,Integer userId);
	
	void deleteUserDetails(int userId);
	
	List<User> findAll();

}
