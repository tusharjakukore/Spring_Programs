package com.hiking.service;

import com.hiking.entity.Payment;

public interface PaymentService {
	
	    Payment addPayment(Payment payment);
		
		Payment getPaymentDetails(int paymentId);
		
		Payment updatePaymentDetails(Payment payment,Integer paymentId);
		
		void deletePaymentDetails(int paymentId);

}
