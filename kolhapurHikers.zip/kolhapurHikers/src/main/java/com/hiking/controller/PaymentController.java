package com.hiking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hiking.entity.Payment;
import com.hiking.service.PaymentService;

import jakarta.validation.Valid;

@RestController
public class PaymentController {
	
	@Autowired
	PaymentService paymentvice;
	
	@PostMapping("/Payment/addPayment")
	public ResponseEntity<Payment> savePayment(@Valid @RequestBody Payment payment)
	{
		return new ResponseEntity<Payment>(paymentvice.addPayment(payment),HttpStatus.CREATED);
	}
	
	@GetMapping("/Payment/getPayment/{paymentId}")
	public ResponseEntity<Payment> getPayment(@PathVariable("paymentId") int paymentId)
	{
		return new ResponseEntity<Payment>(paymentvice.getPaymentDetails(paymentId),HttpStatus.OK);
	}
	
	@DeleteMapping("/Payment/removePayment/{paymentId}")
	public ResponseEntity<String> deletePayment(@PathVariable("paymentId") int paymentId)
	{
		return new ResponseEntity<String>("Delete successfully...",HttpStatus.OK);
	}
	
	//use put mapping to edit existing data
	@PutMapping("/Payment/updatePayment/{paymentId}")
	public ResponseEntity<Payment> editPayment(@PathVariable("paymentId") Integer paymentId, @Valid @RequestBody Payment payment)
	{
		Payment updatePayment=paymentvice.updatePaymentDetails(payment , paymentId);
		return new ResponseEntity<Payment>(updatePayment , HttpStatus.OK); 
	}


}
