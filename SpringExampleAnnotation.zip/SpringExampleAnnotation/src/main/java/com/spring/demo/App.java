package com.spring.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */

//IOC Container (dependancy injection) two ways 1) Contructor  2) Setter 
/*
 * interface BeanFactory {
 * 
 * } interface ApplicationContext extends BeanFactory {
 * 
 * } class ClassPathXmlApplicationContext implements ApplicationContext {
 * 
 * }
 */

public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext context=new 
         		ClassPathXmlApplicationContext("Shape.xml");
				/*
				 * Painter p=(Painter) context.getBean("kalpesh");
				 *  p.perform();
				 */
    	 
    	 Performer p= (Performer) context.getBean("kalpesh");
    	 p.perform();
    }
}
