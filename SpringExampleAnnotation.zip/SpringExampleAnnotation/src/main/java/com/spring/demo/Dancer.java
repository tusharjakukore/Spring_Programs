package com.spring.demo;

import org.springframework.stereotype.Component;

@Component("daaku")
public class Dancer implements Performer {

	@Override
	public void perform() {
		
		System.out.println("dancer is dancing on main hun na song");
		
	}

}
