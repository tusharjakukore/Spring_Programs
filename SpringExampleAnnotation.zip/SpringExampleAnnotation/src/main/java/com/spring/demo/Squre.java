package com.spring.demo;

import org.springframework.stereotype.Component;

@Component("sq")

public class Squre implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("drawing a squre");
	}
	
	

}
