package com.spring.demo;

import org.springframework.stereotype.Component;

@Component("t")
public class Triangle implements Shape {

	String color="red";
	
	
	
	public Triangle() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Triangle(String color) {
		super();
		this.color = color;
	}



	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("painter is drawing "+color+" triangle");
	}
	
	

}
